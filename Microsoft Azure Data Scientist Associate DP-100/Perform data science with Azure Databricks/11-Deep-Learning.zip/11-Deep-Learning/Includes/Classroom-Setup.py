# Databricks notebook source

spark.conf.set("com.databricks.training.module-name", "deep-learning")
spark.conf.set("com.databricks.training.expected-dbr", "6.4")

spark.conf.set("com.databricks.training.suppress.untilStreamIsReady", "true")
spark.conf.set("com.databricks.training.suppress.stopAllStreams", "true")
spark.conf.set("com.databricks.training.suppress.moduleName", "true")
spark.conf.set("com.databricks.training.suppress.lessonName", "true")
# spark.conf.set("com.databricks.training.suppress.username", "true")
spark.conf.set("com.databricks.training.suppress.userhome", "true")
# spark.conf.set("com.databricks.training.suppress.workingDir", "true")
spark.conf.set("com.databricks.training.suppress.databaseName", "true")

import warnings
warnings.filterwarnings("ignore")

import tensorflow
tensorflow.logging.set_verbosity(tensorflow.logging.ERROR)  

def display_run_uri(experiment_id, run_id):
    host_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().tags().get("browserHostName").get()
    uri = "https://{}/#mlflow/experiments/{}/runs/{}".format(host_name,experiment_id,run_id)
    displayHTML("""<b>Run URI:</b> <a href="{}">{}</a>""".format(uri,uri))

def waitForMLflow():
  try:
    import mlflow; 
    if int(mlflow.__version__.split(".")[1]) >= 2:
        print("""The module "mlflow" is attached and ready to go.""");
    else:
        print("""You need MLflow version 1.2.0+ installed.""")
  except ModuleNotFoundError:
    print("""The module "mlflow" is not yet attached to the cluster, waiting...""");
    while True:
      try: import mlflow; print("""The module "mlflow" is attached and ready to go."""); break;
      except ModuleNotFoundError: import time; time.sleep(1); print(".", end="");


from sklearn.metrics import confusion_matrix,f1_score,accuracy_score,fbeta_score,precision_score,recall_score
import matplotlib.pyplot as plt
import numpy as np
from sklearn.utils.multiclass import unique_labels

def plot_confusion_matrix(y_true, y_pred, classes,
                          title=None,
                          cmap=plt.cm.Blues):
    # Compute confusion matrix
    cm = confusion_matrix(y_true, y_pred)
    fig, ax = plt.subplots()
    im = ax.imshow(cm, interpolation='nearest', cmap=cmap)
    ax.figure.colorbar(im, ax=ax)
    ax.set(xticks=np.arange(cm.shape[1]),
           yticks=np.arange(cm.shape[0]),
           xticklabels=classes, yticklabels=classes,
           title=title,
           ylabel='True label',
           xlabel='Predicted label')

    plt.setp(ax.get_xticklabels(), rotation=45, ha="right",
             rotation_mode="anchor")

    fmt = 'd'
    thresh = cm.max() / 2.
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, format(cm[i, j], fmt),
                    ha="center", va="center",
                    color="white" if cm[i, j] > thresh else "black")
    fig.tight_layout()
    return fig

np.set_printoptions(precision=2)

displayHTML("Preparing the learning environment...")

# COMMAND ----------

# MAGIC %run ./Common-Notebooks/Common

# COMMAND ----------


courseAdvertisements["waitForMLflow"] =         ("f", "", "MLflow is an open source platform to manage the ML lifecycle, including experimentation, reproducibility and deployment")
courseAdvertisements["display_run_uri"] =       ("f", "experiment_id, run_id", "Experiment and run ids")
courseAdvertisements["plot_confusion_matrix"] = ("f", "y_true, y_pred, classes, title=None, cmap=plt.cm.Blues", "Confusion matrix")

working_path = workingDir.replace("dbfs:/", "/dbfs/")
courseAdvertisements["working_path"] = ("v", working_path, "This is working directory.")
# Make sure workingDir exists before continuing
dbutils.fs.mkdirs(working_path.replace("/dbfs/", "dbfs:/"))

# Optimized fuse mount
ml_working_path = f"/dbfs/ml/{username.replace('+', '')}"
courseAdvertisements["ml_working_path"] = ("v", ml_working_path, "This is ML working directory.")
# Make sure workingDir exists before continuing
dbutils.fs.mkdirs(ml_working_path.replace("/dbfs/", "dbfs:/"))

dbutils.fs.mkdirs(f"{workingDir}/temp")

allDone(courseAdvertisements)