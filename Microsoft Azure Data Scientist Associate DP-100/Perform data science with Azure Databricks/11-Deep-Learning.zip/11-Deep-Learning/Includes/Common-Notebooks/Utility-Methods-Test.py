# Databricks notebook source
# MAGIC %scala
# MAGIC spark.conf.set("com.databricks.training.module-name", "common-notebooks")
# MAGIC
# MAGIC val courseAdvertisements = scala.collection.mutable.Map[String,(String,String,String)]()

# COMMAND ----------

spark.conf.set("com.databricks.training.module-name", "common-notebooks")

courseAdvertisements = dict()

# COMMAND ----------

# MAGIC %run ./Utility-Methods

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC import scala.collection.mutable.ArrayBuffer
# MAGIC val scalaTests = ArrayBuffer.empty[Boolean]
# MAGIC def functionPassed(result: Boolean) = {
# MAGIC   if (result) {
# MAGIC     scalaTests += true
# MAGIC   } else {
# MAGIC     scalaTests += false
# MAGIC   } 
# MAGIC }

# COMMAND ----------


pythonTests = []
def functionPassed(result):
  if result:
    pythonTests.append(True)
  else:
    pythonTests.append(False)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Test `printRecordsPerPartition`

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC def testPrintRecordsPerPartition(): Boolean = {
# MAGIC   
# MAGIC   // Import Data
# MAGIC   val peopleDF = spark.read.parquet("/mnt/training/dataframes/people-10m.parquet")
# MAGIC   
# MAGIC   // Get printed results
# MAGIC   import java.io.ByteArrayOutputStream
# MAGIC   val printedOutput = new ByteArrayOutputStream
# MAGIC   Console.withOut(printedOutput) {printRecordsPerPartition(peopleDF)}
# MAGIC   
# MAGIC   // Setup tests
# MAGIC   import scala.collection.mutable.ArrayBuffer
# MAGIC   val testsPassed = ArrayBuffer.empty[Boolean]
# MAGIC   
# MAGIC   def passedTest(result: Boolean, message: String = null) = {
# MAGIC     if (result) {
# MAGIC       testsPassed += true
# MAGIC     } else {
# MAGIC       testsPassed += false
# MAGIC       println(s"Failed Test: $message")
# MAGIC     } 
# MAGIC   }
# MAGIC   
# MAGIC   
# MAGIC   // Test if correct number of partitions are printing
# MAGIC   try {
# MAGIC     assert(
# MAGIC       (for (element <- printedOutput.toString.split("\n") if element.startsWith("#")) yield element).size == peopleDF.rdd.getNumPartitions
# MAGIC     )
# MAGIC     passedTest(true)
# MAGIC   } catch {
# MAGIC     case a: AssertionError => {
# MAGIC       passedTest(false, "The correct number of partitions were not identified for printRecordsPerPartition")
# MAGIC     }
# MAGIC     case _: Exception => {
# MAGIC       passedTest(false, "non-descript error for the correct number of partitions were not identified for printRecordsPerPartition")
# MAGIC     }
# MAGIC   }
# MAGIC   
# MAGIC   // Test if each printed partition has a record number associated
# MAGIC   try {
# MAGIC     val recordMap = for (element <- printedOutput.toString.split("\n") if element.startsWith("#")) 
# MAGIC       yield Map(
# MAGIC         element.slice(element.indexOf("#") + 1, element.indexOf(":") - element.indexOf("#")) -> element.split(" ")(1).replace(",", "").toInt
# MAGIC       )
# MAGIC     val recordCounts = (for (map <- recordMap if map.keySet.toSeq(0).toInt.isInstanceOf[Int]) yield map.getOrElse(map.keySet.toSeq(0), -1))
# MAGIC     recordCounts.foreach(x => assert(x.isInstanceOf[Int]))
# MAGIC     recordCounts.foreach(x => assert(x != -1))
# MAGIC     passedTest(true)
# MAGIC   } catch {
# MAGIC     case a: AssertionError => {
# MAGIC       passedTest(false, "Not every partition has an associated record count")
# MAGIC     }
# MAGIC     case _: Exception => {
# MAGIC       passedTest(false, "non-descript error for not every partition having an associated record count")
# MAGIC     }
# MAGIC   }
# MAGIC   
# MAGIC   // Test if the sum of the printed number of records per partition equals the total number of records
# MAGIC   try {
# MAGIC     val printedSum = (
# MAGIC       for (element <- printedOutput.toString.split("\n") if element.startsWith("#")) yield element.split(" ")(1).replace(",", "").toInt
# MAGIC     ).sum
# MAGIC     assert(printedSum == peopleDF.count)
# MAGIC     passedTest(true)
# MAGIC   } catch {
# MAGIC     case a: AssertionError => {
# MAGIC       passedTest(false, "The sum of the number of records per partition does not match the total number of records")
# MAGIC     }
# MAGIC     case _: Exception => {
# MAGIC       passedTest(false, "non-descript error for the sum of the number of records per partition not matching the total number of records")
# MAGIC     }
# MAGIC   }
# MAGIC   
# MAGIC
# MAGIC   val numTestsPassed = testsPassed.groupBy(identity).mapValues(_.size)(true)
# MAGIC   if (numTestsPassed == testsPassed.length) {
# MAGIC     println(s"All $numTestsPassed tests for printRecordsPerPartition passed")
# MAGIC     true
# MAGIC   } else {
# MAGIC     println(s"$numTestsPassed of ${testsPassed.length} tests for printRecordsPerPartition passed")
# MAGIC     false
# MAGIC   }
# MAGIC }
# MAGIC
# MAGIC functionPassed(testPrintRecordsPerPartition())

# COMMAND ----------


def testPrintRecordsPerPartition():
  
    # Import data
    peopleDF = spark.read.parquet("/mnt/training/dataframes/people-10m.parquet")
    
    # Get printed results
    import io
    from contextlib import redirect_stdout

    f = io.StringIO()
    with redirect_stdout(f):
        printRecordsPerPartition(peopleDF)
    out = f.getvalue()
  
    # Setup tests
    testsPassed = []
    
    def passedTest(result, message = None):
        if result:
            testsPassed[len(testsPassed) - 1] = True
        else:
            testsPassed[len(testsPassed) - 1] = False
            print('Failed Test: {}'.format(message))
    
    # Test if correct number of partitions are printing
    testsPassed.append(None)
    try:
        assert int(out[out.rfind('#') + 1]) == peopleDF.rdd.getNumPartitions()
        passedTest(True)
    except:
        passedTest(False, "The correct number of partitions were not identified for printRecordsPerPartition")
        
    # Test if each printed partition has a record number associated
    testsPassed.append(None)
    try:
        output_list = [
          {val.split(" ")[0].replace("#", "").replace(":", ""): int(val.split(" ")[1].replace(",", ""))} 
          for val in out.split("\n") if val and val[0] == "#"
        ]
        assert all([isinstance(x[list(x.keys())[0]], int) for x in output_list])
        passedTest(True)
    except:
        passedTest(False, "Not every partition has an associated record count")
        
    # Test if the sum of the printed number of records per partition equals the total number of records
    testsPassed.append(None)
    try:
        printedSum = sum([
          int(val.split(" ")[1].replace(",", ""))
          for val in out.split("\n") if val and val[0] == "#"
        ])
      
        assert printedSum == peopleDF.count()
        passedTest(True)
    except:
        passedTest(False, "The sum of the number of records per partition does not match the total number of records")
    
    # Print final info and return
    if all(testsPassed):
        print('All {} tests for printRecordsPerPartition passed'.format(len(testsPassed)))
        return True
    else:
        print('{} of {} tests for printRecordsPerPartition passed'.format(testsPassed.count(True), len(testsPassed)))
        return False

functionPassed(testPrintRecordsPerPartition())

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Test `computeFileStats`

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC def testComputeFileStats(): Boolean = {
# MAGIC   
# MAGIC   // Set file path
# MAGIC   val filePath = "/mnt/training/global-sales/transactions/2017.parquet"
# MAGIC   
# MAGIC   // Run and get output
# MAGIC   val output = computeFileStats(filePath)
# MAGIC   
# MAGIC   // Setup tests
# MAGIC   import scala.collection.mutable.ArrayBuffer
# MAGIC   val testsPassed = ArrayBuffer.empty[Boolean]
# MAGIC   
# MAGIC   def passedTest(result: Boolean, message: String = null) = {
# MAGIC     if (result) {
# MAGIC       testsPassed += true
# MAGIC     } else {
# MAGIC       testsPassed += false
# MAGIC       println(s"Failed Test: $message")
# MAGIC     } 
# MAGIC   }
# MAGIC   
# MAGIC   
# MAGIC   // Test if result is correct structure
# MAGIC   try {
# MAGIC     assert(output.getClass.getName.startsWith("scala.Tuple"))
# MAGIC     assert(output.productArity == 2)
# MAGIC     assert(output._1.isInstanceOf[Long])
# MAGIC     assert(output._2.isInstanceOf[Long])
# MAGIC     passedTest(true)
# MAGIC   } catch {
# MAGIC     case a: AssertionError => {
# MAGIC       passedTest(false, "The incorrect structure is returned for computeFileStats")
# MAGIC     }
# MAGIC     case _: Exception => {
# MAGIC       passedTest(false, "non-descript error for the incorrect structure being returned for computeFileStats")
# MAGIC     }
# MAGIC   }
# MAGIC   
# MAGIC   // Test that correct result is returned
# MAGIC   try {
# MAGIC     assert(output._1 == 6276)
# MAGIC     assert(output._2 == 1269333224)
# MAGIC     passedTest(true)
# MAGIC   } catch {
# MAGIC     case a: AssertionError => {
# MAGIC       passedTest(false, "The incorrect result is returned for computeFileStats")
# MAGIC     }
# MAGIC     case _: Exception => {
# MAGIC       passedTest(false, "non-descript error for the incorrect result being returned for computeFileStats")
# MAGIC     }
# MAGIC   }
# MAGIC   
# MAGIC   // Test that nonexistent file path throws error
# MAGIC   try {
# MAGIC     computeFileStats("alkshdahdnoinscoinwincwinecw/cw/cw/cd/c/wcdwdfobnwef")
# MAGIC     passedTest(false, "A nonexistent file path did not throw an error for computeFileStats")
# MAGIC   } catch {
# MAGIC     case a: java.io.FileNotFoundException => {
# MAGIC       passedTest(true)
# MAGIC     }
# MAGIC     case _: Exception => {
# MAGIC       passedTest(false, "non-descript error for a nonexistent file path throwing an error for computeFileStats")
# MAGIC     }
# MAGIC   }
# MAGIC   
# MAGIC
# MAGIC   val numTestsPassed = testsPassed.groupBy(identity).mapValues(_.size)(true)
# MAGIC   if (numTestsPassed == testsPassed.length) {
# MAGIC     println(s"All $numTestsPassed tests for computeFileStats passed")
# MAGIC     true
# MAGIC   } else {
# MAGIC     println(s"$numTestsPassed of ${testsPassed.length} tests for computeFileStats passed")
# MAGIC     false
# MAGIC   }
# MAGIC }
# MAGIC
# MAGIC functionPassed(testComputeFileStats())

# COMMAND ----------


def testComputeFileStats():
  
    # Set file path
    filePath = "/mnt/training/global-sales/transactions/2017.parquet"
  
    # Run and get output
    output = computeFileStats(filePath)
  
    # Setup tests
    testsPassed = []
    
    def passedTest(result, message = None):
        if result:
            testsPassed[len(testsPassed) - 1] = True
        else:
            testsPassed[len(testsPassed) - 1] = False
            print('Failed Test: {}'.format(message))
    
    # Test if correct structure is returned
    testsPassed.append(None)
    try:
        assert isinstance(output, tuple)
        assert len(output) == 2
        assert isinstance(output[0], int)
        assert isinstance(output[1], int)
        passedTest(True)
    except:
        passedTest(False, "The incorrect structure is returned for computeFileStats")
        
    # Test that correct result is returned
    testsPassed.append(None)
    try:
        assert output[0] == 6276
        assert output[1] == 1269333224
        passedTest(True)
    except:
        passedTest(False, "The incorrect result is returned for computeFileStats")
        
    # Test that nonexistent file path throws error
    testsPassed.append(None)
    try:
        computeFileStats("alkshdahdnoinscoinwincwinecw/cw/cw/cd/c/wcdwdfobnwef")
        passedTest(False, "A nonexistent file path did not throw an error for computeFileStats")
    except:
        passedTest(True)
     
    # Print final info and return
    if all(testsPassed):
        print('All {} tests for computeFileStats passed'.format(len(testsPassed)))
        return True
    else:
        print('{} of {} tests for computeFileStats passed'.format(testsPassed.count(True), len(testsPassed)))
        return False

functionPassed(testComputeFileStats())

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Test `cacheAs`

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC def testCacheAs(): Boolean = {
# MAGIC   
# MAGIC   import org.apache.spark.storage.StorageLevel
# MAGIC   // Import DF
# MAGIC   val inputDF = spark.read.parquet("/mnt/training/global-sales/transactions/2017.parquet").limit(100)
# MAGIC   
# MAGIC   // Setup tests
# MAGIC   import scala.collection.mutable.ArrayBuffer
# MAGIC   val testsPassed = ArrayBuffer.empty[Boolean]
# MAGIC   
# MAGIC   def passedTest(result: Boolean, message: String = null) = {
# MAGIC     if (result) {
# MAGIC       testsPassed += true
# MAGIC     } else {
# MAGIC       testsPassed += false
# MAGIC       println(s"Failed Test: $message")
# MAGIC     } 
# MAGIC   }
# MAGIC   
# MAGIC   
# MAGIC   // Test uncached table gets cached
# MAGIC   try {
# MAGIC     cacheAs(inputDF, "testCacheTable12344321", StorageLevel.MEMORY_ONLY)
# MAGIC     assert(spark.catalog.isCached("testCacheTable12344321"))
# MAGIC     passedTest(true)
# MAGIC   } catch {
# MAGIC     case a: AssertionError => {
# MAGIC       passedTest(false, "Uncached table was not cached for cacheAs")
# MAGIC     }
# MAGIC     case _: Exception => {
# MAGIC       passedTest(false, "non-descript error for uncached table being cached for cacheAs")
# MAGIC     }
# MAGIC   }
# MAGIC   
# MAGIC   // Test cached table gets recached
# MAGIC   try {
# MAGIC     cacheAs(inputDF, "testCacheTable12344321", StorageLevel.MEMORY_ONLY)
# MAGIC     assert(spark.catalog.isCached("testCacheTable12344321"))
# MAGIC     spark.catalog.uncacheTable("testCacheTable12344321")
# MAGIC     passedTest(true)
# MAGIC   } catch {
# MAGIC     case a: AssertionError => {
# MAGIC       passedTest(false, "Cached table was not recached for cacheAs")
# MAGIC     }
# MAGIC     case _: Exception => {
# MAGIC       passedTest(false, "non-descript error for cached table being recached for cacheAs")
# MAGIC     }
# MAGIC   }
# MAGIC
# MAGIC   val numTestsPassed = testsPassed.groupBy(identity).mapValues(_.size)(true)
# MAGIC   if (numTestsPassed == testsPassed.length) {
# MAGIC     println(s"All $numTestsPassed tests for cacheAs passed")
# MAGIC     true
# MAGIC   } else {
# MAGIC     println(s"$numTestsPassed of ${testsPassed.length} tests for cacheAs passed")
# MAGIC     false
# MAGIC   }
# MAGIC }
# MAGIC
# MAGIC functionPassed(testCacheAs())

# COMMAND ----------


def testCacheAs():
  
    # Import DF
    inputDF = spark.read.parquet("/mnt/training/global-sales/transactions/2017.parquet").limit(100)
  
    # Setup tests
    testsPassed = []
    
    def passedTest(result, message = None):
        if result:
            testsPassed[len(testsPassed) - 1] = True
        else:
            testsPassed[len(testsPassed) - 1] = False
            print('Failed Test: {}'.format(message))
    
    # Test uncached table gets cached
    testsPassed.append(None)
    try:
        cacheAs(inputDF, "testCacheTable12344321")
        assert spark.catalog.isCached("testCacheTable12344321")
        passedTest(True)
    except:
        passedTest(False, "Uncached table was not cached for cacheAs")
        
    # Test cached table gets recached
    testsPassed.append(None)
    try:
        cacheAs(inputDF, "testCacheTable12344321")
        assert spark.catalog.isCached("testCacheTable12344321")
        passedTest(True)
    except:
        passedTest(False, "Cached table was not recached for cacheAs")
        
    # Test wrong level still gets cached
    testsPassed.append(None)
    try:
        spark.catalog.uncacheTable("testCacheTable12344321")
        cacheAs(inputDF, "testCacheTable12344321", "WRONG_LEVEL")
        assert spark.catalog.isCached("testCacheTable12344321")
        spark.catalog.uncacheTable("testCacheTable12344321")
        passedTest(True)
    except:
        passedTest(False, "Invalid storage level stopping caching for cacheAs")
        
     
    # Print final info and return
    if all(testsPassed):
        print('All {} tests for cacheAs passed'.format(len(testsPassed)))
        return True
    else:
        print('{} of {} tests for cacheAs passed'.format(testsPassed.count(True), len(testsPassed)))
        return False

functionPassed(testCacheAs())

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Test `benchmarkCount()`

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC def testBenchmarkCount(): Boolean = {
# MAGIC   
# MAGIC   def testFunction() = {
# MAGIC     spark.createDataFrame(Seq((1, 2, 3, 4), (5, 6, 7, 8), (9, 10, 11, 12)))
# MAGIC   }
# MAGIC   val output = benchmarkCount(testFunction)
# MAGIC   
# MAGIC   // Setup tests
# MAGIC   import scala.collection.mutable.ArrayBuffer
# MAGIC   val testsPassed = ArrayBuffer.empty[Boolean]
# MAGIC   
# MAGIC   def passedTest(result: Boolean, message: String = null) = {
# MAGIC     if (result) {
# MAGIC       testsPassed += true
# MAGIC     } else {
# MAGIC       testsPassed += false
# MAGIC       println(s"Failed Test: $message")
# MAGIC     } 
# MAGIC   }
# MAGIC   
# MAGIC   
# MAGIC   // Test that correct structure is returned
# MAGIC   try {
# MAGIC     assert(output.getClass.getName.startsWith("scala.Tuple"))
# MAGIC     assert(output.productArity == 3)
# MAGIC     assert(output._1.isInstanceOf[org.apache.spark.sql.DataFrame])
# MAGIC     assert(output._2.isInstanceOf[Long])
# MAGIC     assert(output._3.isInstanceOf[Long])
# MAGIC     passedTest(true)
# MAGIC   } catch {
# MAGIC     case a: AssertionError => {
# MAGIC       passedTest(false, "Correct structure not returned for benchmarkCount")
# MAGIC     }
# MAGIC     case _: Exception => {
# MAGIC       passedTest(false, "non-descript error for correct structure being returned for benchmarkCount")
# MAGIC     }
# MAGIC   }
# MAGIC   
# MAGIC   // Test that correct result is returned
# MAGIC   try {
# MAGIC     assert(output._1.rdd.collect().deep == testFunction().rdd.collect().deep)
# MAGIC     assert(output._2 == testFunction().count())
# MAGIC     assert(output._3 > 0)
# MAGIC     assert(output._3 < 10000)
# MAGIC     passedTest(true)
# MAGIC   } catch {
# MAGIC     case a: AssertionError => {
# MAGIC       passedTest(false, "Uncached table was not cached for cacheAs")
# MAGIC     }
# MAGIC     case _: Exception => {
# MAGIC       passedTest(false, "non-descript error for uncached table being cached for cacheAs")
# MAGIC     }
# MAGIC   }
# MAGIC
# MAGIC   val numTestsPassed = testsPassed.groupBy(identity).mapValues(_.size)(true)
# MAGIC   if (numTestsPassed == testsPassed.length) {
# MAGIC     println(s"All $numTestsPassed tests for benchmarkCount passed")
# MAGIC     true
# MAGIC   } else {
# MAGIC     println(s"$numTestsPassed of ${testsPassed.length} tests for benchmarkCount passed")
# MAGIC     false
# MAGIC   }
# MAGIC }
# MAGIC
# MAGIC functionPassed(testBenchmarkCount())

# COMMAND ----------


def testBenchmarkCount():
  
    from pyspark.sql import DataFrame
    def testFunction():
      return spark.createDataFrame([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12]])
    output = benchmarkCount(testFunction)
 
    # Setup tests
    testsPassed = []
    
    def passedTest(result, message = None):
        if result:
            testsPassed[len(testsPassed) - 1] = True
        else:
            testsPassed[len(testsPassed) - 1] = False
            print('Failed Test: {}'.format(message))
    
    # Test that correct structure is returned
    testsPassed.append(None)
    try:
        assert isinstance(output, tuple)
        assert len(output) == 3
        assert isinstance(output[0], DataFrame)
        assert isinstance(output[1], int)
        assert isinstance(output[2], float)
        passedTest(True)
    except:
        passedTest(False, "Correct structure not returned for benchmarkCount")
        
    # Test that correct result is returned
    testsPassed.append(None)
    try:
        assert output[0].rdd.collect() == testFunction().rdd.collect()
        assert output[1] == testFunction().count()
        assert output[2] > 0 and output[2] < 10000
        passedTest(True)
    except:
        passedTest(False, "Correct structure not returned for benchmarkCount")    
     
    # Print final info and return
    if all(testsPassed):
        print('All {} tests for benchmarkCount passed'.format(len(testsPassed)))
        return True
    else:
        print('{} of {} tests for benchmarkCount passed'.format(testsPassed.count(True), len(testsPassed)))
        return False

functionPassed(testBenchmarkCount())

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Test **`untilStreamIsReady()`**

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC val dataPath = "dbfs:/mnt/training/definitive-guide/data/activity-data-stream.json"
# MAGIC val dataSchema = "Recorded_At timestamp, Device string, Index long, Model string, User string, _corrupt_record String, gt string, x double, y double, z double"
# MAGIC
# MAGIC val initialDF = spark
# MAGIC   .readStream                             // Returns DataStreamReader
# MAGIC   .option("maxFilesPerTrigger", 1)        // Force processing of only 1 file per trigger 
# MAGIC   .schema(dataSchema)                     // Required for all streaming DataFrames
# MAGIC   .json(dataPath)                         // The stream's source directory and file type
# MAGIC
# MAGIC val name = "Testing_123"
# MAGIC
# MAGIC display(initialDF, streamName = name)
# MAGIC untilStreamIsReady(name)
# MAGIC assert(spark.streams.active.length == 1, "Expected 1 active stream, found " + spark.streams.active.length)

# COMMAND ----------

# MAGIC %scala
# MAGIC for (stream <- spark.streams.active) {
# MAGIC   stream.stop()
# MAGIC   var queries = spark.streams.active.filter(_.name == stream.name)
# MAGIC   while (queries.length > 0) {
# MAGIC     Thread.sleep(5*1000) // Give it a couple of seconds
# MAGIC     queries = spark.streams.active.filter(_.name == stream.name)
# MAGIC   }
# MAGIC   println("""The stream "%s" has beend terminated.""".format(stream.name))
# MAGIC }

# COMMAND ----------


dataPath = "dbfs:/mnt/training/definitive-guide/data/activity-data-stream.json"
dataSchema = "Recorded_At timestamp, Device string, Index long, Model string, User string, _corrupt_record String, gt string, x double, y double, z double"

initialDF = (spark
  .readStream                            # Returns DataStreamReader
  .option("maxFilesPerTrigger", 1)       # Force processing of only 1 file per trigger 
  .schema(dataSchema)                    # Required for all streaming DataFrames
  .json(dataPath)                        # The stream's source directory and file type
)

name = "Testing_123"

display(initialDF, streamName = name)
untilStreamIsReady(name)
assert len(spark.streams.active) == 1, "Expected 1 active stream, found " + str(len(spark.streams.active))

# COMMAND ----------

for stream in spark.streams.active:
  stream.stop()
  queries = list(filter(lambda query: query.name == stream.name, spark.streams.active))
  while (len(queries) > 0):
    time.sleep(5) # Give it a couple of seconds
    queries = list(filter(lambda query: query.name == stream.name, spark.streams.active))
  print("""The stream "{}" has been terminated.""".format(stream.name))

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC val numTestsPassed = scalaTests.groupBy(identity).mapValues(_.size)(true)
# MAGIC if (numTestsPassed == scalaTests.length) {
# MAGIC   println(s"All $numTestsPassed tests for Scala passed")
# MAGIC } else {
# MAGIC   println(s"$numTestsPassed of ${scalaTests.length} tests for Scala passed")
# MAGIC   throw new Exception(s"$numTestsPassed of ${scalaTests.length} tests for Scala passed")
# MAGIC }

# COMMAND ----------


if all(pythonTests):
    print('All {} tests for Python passed'.format(len(pythonTests)))
else:
    print('{} of {} tests for Python passed'.format(pythonTests.count(True), len(pythonTests)))
    raise Exception('{} of {} tests for Python passed'.format(pythonTests.count(True), len(pythonTests)))