# Databricks notebook source
# MAGIC %md
# MAGIC # Class-Utility-Methods-Test
# MAGIC The purpose of this notebook is to faciliate testing of courseware-specific utility methos.

# COMMAND ----------

# MAGIC %scala
# MAGIC spark.conf.set("com.databricks.training.module-name", "common-notebooks")

# COMMAND ----------

spark.conf.set("com.databricks.training.module-name", "common-notebooks")

# COMMAND ----------

# MAGIC %md a lot of these tests evolve around the current DBR version.
# MAGIC
# MAGIC It shall be assumed that the cluster is configured properly and that these tests are updated with each publishing of courseware against a new DBR

# COMMAND ----------

# MAGIC %run ./Class-Utility-Methods

# COMMAND ----------

# MAGIC %scala
# MAGIC def functionPassed(result: Boolean) = {
# MAGIC   if (!result) {
# MAGIC     assert(false, "Test failed")
# MAGIC   } 
# MAGIC }

# COMMAND ----------

def functionPassed(result):
  if not result:
    raise AssertionError("Test failed")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Test `getTags`

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC def testGetTags(): Boolean = {
# MAGIC   
# MAGIC   val testTags = getTags()
# MAGIC   
# MAGIC   import scala.collection.mutable.ArrayBuffer
# MAGIC
# MAGIC   val testsPassed = ArrayBuffer.empty[Boolean]
# MAGIC   
# MAGIC   def passedTest(result: Boolean, message: String = null) = {
# MAGIC     if (result) {
# MAGIC       testsPassed += true
# MAGIC     } else {
# MAGIC       testsPassed += false
# MAGIC       println(s"Failed Test: $message")
# MAGIC     } 
# MAGIC   }
# MAGIC   
# MAGIC   // Test that tags result is correct type
# MAGIC   try {
# MAGIC     assert(testTags.isInstanceOf[Map[com.databricks.logging.TagDefinition,String]])
# MAGIC     passedTest(true)
# MAGIC   } catch {
# MAGIC     case a: AssertionError => {
# MAGIC       passedTest(false, "tags is not an instance of Map[com.databricks.logging.TagDefinition,String]")
# MAGIC     }
# MAGIC     case _: Exception => {
# MAGIC       passedTest(false, "non-descript error for tags being an instance of Map[com.databricks.logging.TagDefinition,String]")
# MAGIC     }
# MAGIC   }
# MAGIC
# MAGIC   val numTestsPassed = testsPassed.groupBy(identity).mapValues(_.size)(true)
# MAGIC   if (numTestsPassed == testsPassed.length) {
# MAGIC     println(s"All $numTestsPassed tests for getTags passed")
# MAGIC     true
# MAGIC   } else {
# MAGIC     throw new Exception(s"$numTestsPassed of ${testsPassed.length} tests for getTags passed")
# MAGIC   }
# MAGIC }
# MAGIC
# MAGIC functionPassed(testGetTags())

# COMMAND ----------


def testGetTags():
  
    testTags = getTags()
    
    # Setup tests
    testsPassed = []
    
    def passedTest(result, message = None):
        if result:
            testsPassed[len(testsPassed) - 1] = True
        else:
            testsPassed[len(testsPassed) - 1] = False
            print('Failed Test: {}'.format(message))
    
    # Test that getTags returns correct type
    testsPassed.append(None)
    try:
        from py4j.java_collections import JavaMap
        assert isinstance(getTags(), JavaMap)
        passedTest(True)
    except:
        passedTest(False, "The correct type is not returned by getTags")
        
    # Test that getTags does not return an empty dict
    testsPassed.append(None)
    try:
        assert len(testTags) > 0
        passedTest(True)
    except:
        passedTest(False, "A non-empty dict is returned by getTags")
    
    # Print final info and return
    if all(testsPassed):
        print('All {} tests for getTags passed'.format(len(testsPassed)))
        return True
    else:
        raise Exception('{} of {} tests for getTags passed'.format(testsPassed.count(True), len(testsPassed)))

functionPassed(testGetTags())

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Test `getTag()`

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC def testGetTag(): Boolean = {
# MAGIC   
# MAGIC   import scala.collection.mutable.ArrayBuffer
# MAGIC   
# MAGIC   val testsPassed = ArrayBuffer.empty[Boolean]
# MAGIC   
# MAGIC   def passedTest(result: Boolean, message: String = null) = {
# MAGIC     if (result) {
# MAGIC       testsPassed += true
# MAGIC     } else {
# MAGIC       testsPassed += false
# MAGIC       println(s"Failed Test: $message")
# MAGIC     } 
# MAGIC   }
# MAGIC   
# MAGIC   // Test that returns null when not present
# MAGIC   try {
# MAGIC     assert(getTag("thiswillneverbeincluded") == null)
# MAGIC     passedTest(true)
# MAGIC   } catch {
# MAGIC     case e: Exception => passedTest(false, "tag value for 'thiswillneverbeincluded' is not null")
# MAGIC   }
# MAGIC   
# MAGIC   // Test that default value is returned when not present
# MAGIC   try {
# MAGIC     assert(getTag("thiswillneverbeincluded", "default-test").contentEquals("default-test"))
# MAGIC     passedTest(true)
# MAGIC   } catch {
# MAGIC     case e: Exception => passedTest(false, "tag value for 'thiswillneverbeincluded' is not the default value")
# MAGIC   }
# MAGIC   
# MAGIC   // Test that correct result is returned when default value is not set
# MAGIC   try {
# MAGIC     val orgId = getTags().collect({ case (t, v) if t.name == "orgId" => v }).toSeq(0)
# MAGIC     assert(orgId.isInstanceOf[String])
# MAGIC     assert(orgId.size > 0)
# MAGIC     assert(orgId.contentEquals(getTag("orgId")))
# MAGIC     passedTest(true)
# MAGIC   } catch {
# MAGIC     case e: Exception => passedTest(false, "Unexpected tag value returned for getTag")
# MAGIC   }
# MAGIC
# MAGIC   // Print final info and return
# MAGIC   val numTestsPassed = testsPassed.groupBy(identity).mapValues(_.size)(true)
# MAGIC   if (numTestsPassed == testsPassed.length) {
# MAGIC     println(s"All $numTestsPassed tests for getTag passed")
# MAGIC     true
# MAGIC   } else {
# MAGIC     throw new Exception(s"$numTestsPassed of ${testsPassed.length} tests for getTag passed")
# MAGIC   }
# MAGIC }
# MAGIC
# MAGIC functionPassed(testGetTag())

# COMMAND ----------


def testGetTag():
    
    # Setup tests
    testsPassed = []
    
    def passedTest(result, message = None):
        if result:
            testsPassed[len(testsPassed) - 1] = True
        else:
            testsPassed[len(testsPassed) - 1] = False
            print('Failed Test: {}'.format(message))
    
    # Test that getTag returns null when defaultValue is not set and tag is not present
    testsPassed.append(None)
    try:
        assert getTag("thiswillneverbeincluded") == None
        passedTest(True)
    except:
        passedTest(False, "NoneType is not returned when defaultValue is not set and tag is not present for getTag")
        
    # Test that getTag returns defaultValue when it is set and tag is not present
    testsPassed.append(None)
    try:
        assert getTag("thiswillneverbeincluded", "default-value") == "default-value"
        passedTest(True)
    except:
        passedTest(False, "defaultValue is not returned when defaultValue is set and tag is not present for getTag")
        
    # Test that getTag returns correct value when default value is not set and tag is present
    testsPassed.append(None)
    try:
        orgId = getTags()["orgId"]
        assert isinstance(orgId, str)
        assert len(orgId) > 0
        assert orgId == getTag("orgId")
        passedTest(True)
    except:
        passedTest(False, "A non-empty dict is returned by getTags")
    
    # Print final info and return
    if all(testsPassed):
        print('All {} tests for getTag passed'.format(len(testsPassed)))
        return True
    else:
        raise Exception('{} of {} tests for getTag passed'.format(testsPassed.count(True), len(testsPassed)))

functionPassed(testGetTag())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Test `getDbrMajorAndMinorVersions()`

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC def testGetDbrMajorAndMinorVersions(): Boolean = {
# MAGIC   // We cannot rely on the assumption that all courses are
# MAGIC   // running latestDbrMajor.latestDbrMinor. The best we
# MAGIC   // can do here is make sure it matches the environment
# MAGIC   // variable from which it came.
# MAGIC   val dbrVersion = System.getenv().get("DATABRICKS_RUNTIME_VERSION")
# MAGIC   
# MAGIC   val (major,minor) = getDbrMajorAndMinorVersions()
# MAGIC   assert(dbrVersion.startsWith(f"${major}.${minor}"), f"Found ${major}.${minor} for ${dbrVersion}")
# MAGIC   
# MAGIC   return true
# MAGIC }
# MAGIC
# MAGIC functionPassed(testGetDbrMajorAndMinorVersions())

# COMMAND ----------


def testGetDbrMajorAndMinorVersions():
  import os
  # We cannot rely on the assumption that all courses are
  # running latestDbrMajor.latestDbrMinor. The best we
  # can do here is make sure it matches the environment
  # variable from which it came.
  dbrVersion = os.environ["DATABRICKS_RUNTIME_VERSION"]
  
  (major,minor) = getDbrMajorAndMinorVersions()
  assert dbrVersion.startswith(f"{major}.{minor}"), f"Found {major}.{minor} for {dbrVersion}"
  
  return True
      
functionPassed(testGetDbrMajorAndMinorVersions())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Test `getPythonVersion()`

# COMMAND ----------


def testGetPythonVersion():
    
    # Setup tests
    testsPassed = []
    
    def passedTest(result, message = None):
        if result:
            testsPassed[len(testsPassed) - 1] = True
        else:
            testsPassed[len(testsPassed) - 1] = False
            print('Failed Test: {}'.format(message))
    
    # Test output for structure
    testsPassed.append(None)
    try:
        pythonVersion = getPythonVersion()
        assert isinstance(pythonVersion, str)
        assert len(pythonVersion.split(".")) >= 2
        passedTest(True)
    except:
        passedTest(False, "pythonVersion does not match expected structure")
        
    # Test output for correctness
    testsPassed.append(None)
    try:
        pythonVersion = getPythonVersion()
        assert pythonVersion[0] == "2" or pythonVersion[0] == "3"
        passedTest(True)
    except:
        passedTest(False, "pythonVersion does not match expected value")
        

    # Print final info and return
    if all(testsPassed):
        print('All {} tests for getPythonVersion passed'.format(len(testsPassed)))
        return True
    else:
        raise Exception('{} of {} tests for getPythonVersion passed'.format(testsPassed.count(True), len(testsPassed)))

functionPassed(testGetPythonVersion())

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Test `getUsername()`

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC def testGetUsername(): Boolean = {
# MAGIC   val username = getUsername()
# MAGIC   assert(username.isInstanceOf[String])
# MAGIC   assert(!username.contentEquals(""))
# MAGIC   
# MAGIC   return true
# MAGIC }
# MAGIC functionPassed(testGetUsername())

# COMMAND ----------


def testGetUsername():
  username = getUsername()
  assert isinstance(username, str)
  assert username != ""
  
  return True
    
functionPassed(testGetUsername())

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Test `getUserhome`

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC def testGetUserhome(): Boolean = {
# MAGIC   val userhome = getUserhome()
# MAGIC   assert(userhome.isInstanceOf[String])
# MAGIC   assert(!userhome.contentEquals(""))
# MAGIC   assert(userhome == "dbfs:/user/" + getUsername())
# MAGIC     
# MAGIC   return true
# MAGIC }
# MAGIC
# MAGIC functionPassed(testGetUserhome())

# COMMAND ----------


def testGetUserhome():
  userhome = getUserhome()
  assert isinstance(userhome, str)
  assert userhome != ""
  assert userhome == "dbfs:/user/" + getUsername()
    
  return True

functionPassed(testGetUserhome())

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Test `assertDbrVersion`

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC def testAssertDbrVersion(): Boolean = {
# MAGIC   
# MAGIC   val (majorVersion, minorVersion) = getDbrMajorAndMinorVersions()
# MAGIC   val major = majorVersion.toInt
# MAGIC   val minor = minorVersion.toInt
# MAGIC
# MAGIC   val goodVersions = Seq(
# MAGIC     ("SG1", major-1, minor-1),
# MAGIC     ("SG2", major-1, minor),
# MAGIC     ("SG3", major, minor-1),
# MAGIC     ("SG4", major, minor)
# MAGIC   )
# MAGIC   
# MAGIC   for ( (name, testMajor, testMinor) <- goodVersions) {
# MAGIC     println(f"-- ${name} ${testMajor}.${testMinor}")
# MAGIC     assertDbrVersion(null, testMajor, testMinor, false)
# MAGIC     println(f"-"*80)
# MAGIC   }
# MAGIC
# MAGIC   val badVersions = Seq(
# MAGIC     ("SB1", major+1, minor+1),
# MAGIC     ("SB2", major+1, minor),
# MAGIC     ("SB3", major, minor+1)
# MAGIC   )
# MAGIC
# MAGIC   for ( (name, testMajor, testMinor) <- badVersions) {
# MAGIC     try {
# MAGIC       println(f"-- ${name} ${testMajor}.${testMinor}")
# MAGIC       assertDbrVersion(null, testMajor, testMinor, false)
# MAGIC       throw new Exception("Expected AssertionError")
# MAGIC     } catch {
# MAGIC       case e: AssertionError => println(e)
# MAGIC     }
# MAGIC     println(f"-"*80)
# MAGIC   }
# MAGIC   return true
# MAGIC }
# MAGIC functionPassed(testAssertDbrVersion())

# COMMAND ----------


def testAssertDbrVersion():
  
  (majorVersion, minorVersion) = getDbrMajorAndMinorVersions()
  major = int(majorVersion)
  minor = int(minorVersion)

  goodVersions = [
    ("PG1", major-1, minor-1),
    ("PG2", major-1, minor),
    ("PG3", major, minor-1),
    ("PG4", major, minor)
  ]
  
  for (name, testMajor, testMinor) in goodVersions:
    print(f"-- {name} {testMajor}.{testMinor}")
    assertDbrVersion(None, testMajor, testMinor, False)
    print(f"-"*80)

  badVersions = [
    ("PB1", major+1, minor+1),
    ("PB2", major+1, minor),
    ("PB3", major, minor+1)
  ]

  for (name, testMajor, testMinor) in badVersions:
    try:
      print(f"-- {name} {testMajor}.{testMinor}")
      assertDbrVersion(None, testMajor, testMinor, False)
      raise Exception("Expected AssertionError")
      
    except AssertionError as e:
      print(e)
    
    print(f"-"*80)

  return True
        
functionPassed(testAssertDbrVersion())

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Test `assertIsMlRuntime`

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC // def testAssertIsMlRuntime(): Boolean = {
# MAGIC     
# MAGIC //   assertIsMlRuntime("5.5.x-ml-scala2.11")
# MAGIC //   assertIsMlRuntime("5.5.x-cpu-ml-scala2.11")
# MAGIC
# MAGIC //   try {
# MAGIC //     assertIsMlRuntime("5.5.x-scala2.11")
# MAGIC //     assert(false, s"Expected to throw an IllegalArgumentException")
# MAGIC //   } catch {
# MAGIC //     case _: AssertionError => ()
# MAGIC //   }
# MAGIC
# MAGIC //   try {
# MAGIC //     assertIsMlRuntime("5.5.xml-scala2.11")
# MAGIC //     assert(false, s"Expected to throw an IllegalArgumentException")
# MAGIC //   } catch {
# MAGIC //     case _: AssertionError => ()
# MAGIC //   }
# MAGIC
# MAGIC //   return true
# MAGIC // }
# MAGIC // functionPassed(testAssertIsMlRuntime())

# COMMAND ----------


# def testAssertIsMlRuntime():

#   assertIsMlRuntime("6.3.x-ml-scala2.11")
#   assertIsMlRuntime("6.3.x-cpu-ml-scala2.11")

#   try:
#     assertIsMlRuntime("5.5.x-scala2.11")
#     assert False, "Expected to throw an ValueError"
#   except AssertionError:
#     pass

#   try:
#     assertIsMlRuntime("5.5.xml-scala2.11")
#     assert False, "Expected to throw an ValueError"
#   except AssertionError:
#     pass

#   return True

# functionPassed(testAssertIsMlRuntime())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Test Legacy Functions
# MAGIC
# MAGIC Note: Legacy functions will not be tested. Use at your own risk.

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Test `createUserDatabase`

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC def testCreateUserDatabase(): Boolean = {
# MAGIC
# MAGIC   val courseType = "wa"
# MAGIC   val username = "mickey.mouse@disney.com"
# MAGIC   val moduleName = "Testing-Stuff 101"
# MAGIC   val lessonName = "TS 03 - Underwater Basket Weaving"
# MAGIC   
# MAGIC   // Test that correct database name is returned
# MAGIC   val expectedDatabaseName = "mickey_mouse_disney_com" + "_" + "testing_stuff_101" + "_" + "ts_03_underwater_basket_weaving" + "_" + "s" + "wa"
# MAGIC   
# MAGIC   val databaseName = getDatabaseName(courseType, username, moduleName, lessonName)
# MAGIC   assert(databaseName == expectedDatabaseName)
# MAGIC   
# MAGIC   val actualDatabaseName = createUserDatabase(courseType, username, moduleName, lessonName)
# MAGIC   assert(actualDatabaseName == expectedDatabaseName)
# MAGIC
# MAGIC   assert(spark.sql(s"SHOW DATABASES LIKE '$expectedDatabaseName'").first.getAs[String]("databaseName") == expectedDatabaseName)
# MAGIC   assert(spark.sql("SELECT current_database()").first.getAs[String]("current_database()") == expectedDatabaseName)
# MAGIC   
# MAGIC   return true
# MAGIC }
# MAGIC functionPassed(testCreateUserDatabase())

# COMMAND ----------


def testCreateUserDatabase(): 

  courseType = "wa"
  username = "mickey.mouse@disney.com"
  moduleName = "Testing-Stuff 101"
  lessonName = "TS 03 - Underwater Basket Weaving"
  
  # Test that correct database name is returned
  expectedDatabaseName = "mickey_mouse_disney_com" + "_" + "testing_stuff_101" + "_" + "ts_03_underwater_basket_weaving" + "_" + "p" + "wa"
  
  databaseName = getDatabaseName(courseType, username, moduleName, lessonName)
  assert databaseName == expectedDatabaseName, "Expected {}, found {}".format(expectedDatabaseName, databaseName)
  
  actualDatabaseName = createUserDatabase(courseType, username, moduleName, lessonName)
  assert actualDatabaseName == expectedDatabaseName, "Expected {}, found {}".format(expectedDatabaseName, databaseName)

  assert spark.sql(f"SHOW DATABASES LIKE '{expectedDatabaseName}'").first()["databaseName"] == expectedDatabaseName
  assert spark.sql("SELECT current_database()").first()["current_database()"] == expectedDatabaseName
  
  return True

functionPassed(testCreateUserDatabase())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Test `getExperimentId()`

# COMMAND ----------

# MAGIC %scala
# MAGIC def testGetExperimentId(): Boolean = {
# MAGIC   
# MAGIC   import scala.collection.mutable.ArrayBuffer
# MAGIC
# MAGIC   val testsPassed = ArrayBuffer.empty[Boolean]
# MAGIC   
# MAGIC   def passedTest(result: Boolean, message: String = null) = {
# MAGIC     if (result) {
# MAGIC       testsPassed += true
# MAGIC     } else {
# MAGIC       testsPassed += false
# MAGIC       println(s"Failed Test: $message")
# MAGIC     } 
# MAGIC   }
# MAGIC   
# MAGIC   // Test that result is correct type
# MAGIC   try {
# MAGIC     assert(getExperimentId().isInstanceOf[Long])
# MAGIC     passedTest(true)
# MAGIC   } catch {
# MAGIC     case e: Exception => passedTest(false, "result of getExperimentId is not of Long type")
# MAGIC   }
# MAGIC   
# MAGIC   // Note that the tags are an immutable map so we can't test other values
# MAGIC   // Another option is add parameters to getExperimentId, but that could break existing uses
# MAGIC   
# MAGIC   // Test that result comes out as expected
# MAGIC   try {
# MAGIC     val notebookId = try {
# MAGIC       com.databricks.logging.AttributionContext.current.tags(com.databricks.logging.TagDefinition("notebookId", ""))
# MAGIC     } catch {
# MAGIC       case e: Exception => null
# MAGIC     }
# MAGIC     val jobId = try {
# MAGIC       com.databricks.logging.AttributionContext.current.tags(com.databricks.logging.TagDefinition("jobId", ""))
# MAGIC     } catch {
# MAGIC       case e: Exception => null
# MAGIC     }
# MAGIC     val expectedResult = if (notebookId != null){
# MAGIC       notebookId.toLong
# MAGIC     } else {
# MAGIC       if (jobId != null) {
# MAGIC         jobId.toLong
# MAGIC       } else {
# MAGIC         0
# MAGIC       }
# MAGIC     }
# MAGIC     assert(expectedResult == getExperimentId())
# MAGIC     passedTest(true)
# MAGIC   } catch {
# MAGIC     case e: Exception => passedTest(false, "unexpected result for getExperimentId")
# MAGIC   }
# MAGIC   
# MAGIC   val numTestsPassed = testsPassed.groupBy(identity).mapValues(_.size)(true)
# MAGIC   if (numTestsPassed == testsPassed.length) {
# MAGIC     println(s"All $numTestsPassed tests for getExperimentId passed")
# MAGIC     true
# MAGIC   } else {
# MAGIC     throw new Exception(s"$numTestsPassed of ${testsPassed.length} tests for getExperimentId passed")
# MAGIC   }
# MAGIC }
# MAGIC
# MAGIC functionPassed(testGetExperimentId())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Test `classroomCleanup()`

# COMMAND ----------

# MAGIC %scala
# MAGIC classroomCleanup(daLogger, "sp", getUsername(), getModuleName(), getLessonName(), false)

# COMMAND ----------

# MAGIC %scala
# MAGIC classroomCleanup(daLogger, "il", getUsername(), getModuleName(), getLessonName(), true)

# COMMAND ----------

# MAGIC %scala
# MAGIC classroomCleanup(daLogger, "sp", getUsername(), getModuleName(), getLessonName(), false)

# COMMAND ----------

# MAGIC %scala
# MAGIC classroomCleanup(daLogger, "il", getUsername(), getModuleName(), getLessonName(), true)

# COMMAND ----------

classroomCleanup(daLogger, "sp", getUsername(), getModuleName(), getLessonName(), False)

# COMMAND ----------

classroomCleanup(daLogger, "il", getUsername(), getModuleName(), getLessonName(), True)

# COMMAND ----------

classroomCleanup(daLogger, "sp", getUsername(), getModuleName(), getLessonName(), False)

# COMMAND ----------

classroomCleanup(daLogger, "il", getUsername(), getModuleName(), getLessonName(), True)

# COMMAND ----------

# MAGIC %md ## Test FILL_IN

# COMMAND ----------

# MAGIC %scala
# MAGIC println(FILL_IN)
# MAGIC println(FILL_IN.VALUE)
# MAGIC println(FILL_IN.ARRAY)
# MAGIC println(FILL_IN.SCHEMA)
# MAGIC println(FILL_IN.ROW)
# MAGIC println(FILL_IN.LONG)
# MAGIC println(FILL_IN.INT)
# MAGIC println(FILL_IN.DATAFRAME)
# MAGIC println(FILL_IN.DATASET)

# COMMAND ----------

print(FILL_IN)
print(FILL_IN.VALUE)
print(FILL_IN.LIST)
print(FILL_IN.SCHEMA)
print(FILL_IN.ROW)
print(FILL_IN.INT)
print(FILL_IN.DATAFRAME)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Test `showStudentSurvey()`

# COMMAND ----------

# MAGIC %scala
# MAGIC val html = renderStudentSurvey()

# COMMAND ----------

html = renderStudentSurvey()
print(html)

# COMMAND ----------

showStudentSurvey()

# COMMAND ----------

# MAGIC %scala
# MAGIC showStudentSurvey()

# COMMAND ----------

